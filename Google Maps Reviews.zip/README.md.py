import pandas as pd
import os
import time
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain.prompts import PromptTemplate

# --- ⚙️ CONFIGURATION ⚙️ ---
INPUT_FILE = "data/reviews_raw.csv"
OUTPUT_FILE = "data/reviews_analyzed.csv"

# 🔑 PASTE YOUR GOOGLE API KEY HERE
GOOGLE_API_KEY = "PASTE_YOUR_KEY_HERE" 

def analyze_reviews():
    # 1. LOAD DATA
    if not os.path.exists(INPUT_FILE):
        print(f"❌ Error: {INPUT_FILE} not found. Run data_fetcher.py first.")
        return
    
    df = pd.read_csv(INPUT_FILE)
    print(f"📂 Loaded {len(df)} reviews from {INPUT_FILE}")

    # 2. CONNECT TO GOOGLE GEMINI
    print(f"🧠 Connecting to Google Gemini (Cloud AI)...")
    try:
        # We use 'gemini-1.5-flash' because it is fast and free
        llm = ChatGoogleGenerativeAI(
            model="gemini-1.5-flash",
            google_api_key=GOOGLE_API_KEY,
            temperature=0
        )
    except Exception as e:
        print(f"❌ Error connecting to Google: {e}")
        return

    # 3. DEFINE THE PROMPT
    template = """
    You are a business analyst. Analyze this customer review.
    
    Review: "{text}"
    Rating: {rating}/5.0
    
    Output strictly in this format:
    Sentiment: [Positive / Neutral / Negative]
    Themes: [Comma-separated topics, e.g. Service, Price, Quality]
    Summary: [1 sentence summary]
    Recommendation: [1 actionable tip for the business]
    """
    
    prompt = PromptTemplate(template=template, input_variables=["text", "rating"])
    chain = prompt | llm

    # 4. RUN ANALYSIS
    print(f"\n🚀 Starting Analysis on {len(df)} reviews...")
    print("   (Using Google Cloud - Speed: ~4 seconds per review to stay free)")
    print("="*60)
    
    analyzed_data = []
    
    for index, row in df.iterrows():
        text = str(row.get('text', ''))
        rating = row.get('rating', 0)
        author = row.get('author', 'Unknown')
        
        # Skip garbage data
        if len(text) < 5 or "No Text" in text:
            continue
            
        print(f" ➤ Analyzing Review #{index+1} by {author}...")
        
        try:
            # Send to Google AI
            response = chain.invoke({"text": text, "rating": rating})
            content = response.content
            
            # Helper to extract lines
            lines = content.split('\n')
            def extract(key):
                for line in lines:
                    if key in line:
                        parts = line.split(':', 1)
                        if len(parts) > 1: return parts[1].strip()
                return "N/A"

            # Print result to terminal
            sentiment = extract("Sentiment")
            print(f"   ↳ Sentiment: {sentiment}")

            analyzed_data.append({
                "author": author,
                "rating": rating,
                "original_text": text,
                "sentiment": sentiment,
                "themes": extract("Themes"),
                "summary": extract("Summary"),
                "recommendation": extract("Recommendation")
            })
            
            # 🛑 IMPORTANT: Sleep to respect Free Tier limits (15 requests/min)
            time.sleep(4) 
            
        except Exception as e:
            print(f"   ⚠️ Error: {e}")
            time.sleep(10) # Wait longer if we hit a rate limit
            continue

    # 5. SAVE RESULTS
    if analyzed_data:
        results_df = pd.DataFrame(analyzed_data)
        results_df.to_csv(OUTPUT_FILE, index=False)
        print("="*60)
        print(f"✅ ANALYSIS COMPLETE!")
        print(f"💾 Results saved to: {OUTPUT_FILE}")
        
        # OPTIONAL: Delete heavy Ollama files now if you want space back
        # print("💡 Tip: You can now run 'ollama rm phi3' to free up 2.4GB")
    else:
        print("⚠️ No valid text reviews found to analyze.")

if __name__ == "__main__":
    if "PASTE_YOUR_KEY_HERE" in GOOGLE_API_KEY:
        print("❌ STOP! You forgot to paste your API Key in the script.")
    else:
        analyze_reviews()